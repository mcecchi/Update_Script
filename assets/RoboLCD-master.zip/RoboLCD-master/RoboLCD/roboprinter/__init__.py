printer_instance = None 
robo_screen = None
open_tab = None
back_screen = None
robosm = None
