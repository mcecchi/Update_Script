class Robo_SM():

    robo_sm = []
    def get_sm(self):
        pass
        return self.robo_sm
    def set_sm(self, _sm):
        self.robo_sm = _sm

screen_manager = Robo_SM()