printer_instance = None 
