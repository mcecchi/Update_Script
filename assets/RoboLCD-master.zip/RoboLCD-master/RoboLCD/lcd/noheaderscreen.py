from kivy.uix.screenmanager import Screen


class NoHeaderScreen(Screen):
    pass
