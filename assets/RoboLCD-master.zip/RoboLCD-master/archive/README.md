This repository does not currently reflect the structure of the final plugin. This repo doesn't even have the structure of a plugin. 
The first and current stage of development will be to create a functional kivy template. Second stage of development will require this repo to change into a plugin. Octoprint functionality and data-binding efforts will commence during second stage.

TODO:
	1. Template out the UI
	2. Add functionality to UI