from kivy.uix.boxlayout import BoxLayout

"""
The three layouts that will populate the container under the MainScreen tab head.
"""


class FilesTab(BoxLayout):
    pass


class SettingsTab(BoxLayout):
    pass


class PrinterStatusTab(BoxLayout):
    pass
